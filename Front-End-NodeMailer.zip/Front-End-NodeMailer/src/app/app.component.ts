import { Component } from '@angular/core';
import {FormGroup,FormBuilder,Validators} from '@angular/forms';
import {EmailService} from './services/email.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'nodeMailerApp';
  nodeMailerForm :FormGroup;

  constructor(private formBuilder:FormBuilder,private emailService:EmailService){}

  ngOnInit(){
    this.nodeMailerForm = this.formBuilder.group({
       email:[null,[Validators.required]]
    });
  }

  sendMail(){
    alert("jjj");
    let email  = this.nodeMailerForm.value.email;
    let reqObj = {
      email:email
    }
    this.emailService.sendMessage(reqObj).subscribe(data=>{
      console.log(data);
    })
  }
}
